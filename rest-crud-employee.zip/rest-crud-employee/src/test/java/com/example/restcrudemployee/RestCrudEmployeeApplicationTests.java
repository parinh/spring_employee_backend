package com.example.restcrudemployee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestCrudEmployeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
