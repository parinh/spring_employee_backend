package com.example.restcrudemployee.response;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class EmployeeErrorResponse  {
    private int status;
    private String message;
    private Long timeStamp;
}
