package com.example.restcrudemployee;

import com.example.restcrudemployee.entity.Employee;
import com.example.restcrudemployee.service.EmployeeService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class RestCrudEmployeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestCrudEmployeeApplication.class, args);
	}

	@Bean
	public CommandLineRunner commandLineRunner(EmployeeService employeeService) {
		return runner -> {
			System.out.println("commandLineRunner method is called.");
			createMultipleEmployee(employeeService);
		};
	}

	public void createMultipleEmployee(EmployeeService employeeService){
		Employee employee1 = new Employee("parin1","hopper1","kane1",50000,"current","bangkok1","dev1");
		Employee employee2 = new Employee("parin2","hopper2","kane2",50000,"current","bangkok2","dev2");
		Employee employee3 = new Employee("parin3","hopper3","kane3",50000,"current","bangkok3","dev3");
		Employee employee4 = new Employee("parin4","hopper4","kane4",50000,"current","bangkok4","dev4");
		Employee employee5 = new Employee("parin5","hopper5","kane5",50000,"current","bangkok5","dev5");
		employeeService.save(employee1);
		employeeService.save(employee2);
		employeeService.save(employee3);
		employeeService.save(employee4);
		employeeService.save(employee5);
	}

}
