package com.example.restcrudemployee.rest;

import com.example.restcrudemployee.entity.Employee;
import com.example.restcrudemployee.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class EmployeeController {

    @Autowired
    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }
    private EmployeeService employeeService;

    @GetMapping("/employees")
    public List<Employee> getAllEmployees(){
        return employeeService.findAll();
    }
    @GetMapping("/employees/{id}")
    public Employee getEmployeeById(@PathVariable("id") int id){
        Employee employee = employeeService.getById(id);
        if(employee == null){
            throw new RuntimeException("Employee not found");
        }
        return employee;
    }

    @PostMapping("/employees")
    public Employee createEmployee(@RequestBody Employee employee){
        employee.setStatus("current");
        return employeeService.save(employee);
    }

    @PutMapping("/employees")
    public Employee updateEmployee(@RequestBody Employee employee){
        employeeService.update(employee);
        return employeeService.getById(employee.getId());
    }

    @PutMapping("/employees/salary/{id}")
    public String updateEmployeeSalaryByPercent(@PathVariable("id") int id , @RequestParam("percent") int percent){
        employeeService.updateSalaryByPercent(id,percent);
        return "Success";
    }

    @PutMapping("/employees/position/{id}")
    public String updateEmployeePosition(@PathVariable("id") int id ,@RequestParam("old_pos") String old_pos,@RequestParam("new_pos") String new_pos){
        employeeService.updatePosition(id,old_pos,new_pos);
        return "Success";
    }

    @DeleteMapping("/employees/{id}")
    public ResponseEntity<?> deleteEmployeeById(@PathVariable("id") int id){
       employeeService.delete(id);
       return ResponseEntity.status(HttpStatus.NO_CONTENT).body("");
    }

    @GetMapping("/employees/name")
    public List<Employee> getEmployeeLikeInName(@RequestParam("q") String sub_str){
        return employeeService.getLikeInName(sub_str);
    }

    @DeleteMapping("/employees")
    public ResponseEntity<?> deleteEmployeeByIds(@RequestParam("ids") List<Integer> ids){
        List<Integer> notfound_list = employeeService.deleteByIds(ids);
        if(notfound_list.size() > 0 ) return ResponseEntity.status(HttpStatus.MULTI_STATUS).body(notfound_list);
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("");
    }
}
