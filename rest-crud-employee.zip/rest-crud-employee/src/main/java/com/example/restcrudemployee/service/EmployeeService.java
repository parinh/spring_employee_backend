package com.example.restcrudemployee.service;

import com.example.restcrudemployee.entity.Employee;

import java.util.List;

public interface EmployeeService {
    List<Employee> findAll();

    Employee getById(int id);

    Employee save(Employee employee);

    void update(Employee employee);

    void delete(int id);

    void updateSalaryByPercent(Integer id, Integer percent);

    void updatePosition(Integer id, String old_pos , String new_pos);

    List<Employee> getLikeInName (String sub_str);

    List<Integer> deleteByIds (List<Integer> ids);
}
