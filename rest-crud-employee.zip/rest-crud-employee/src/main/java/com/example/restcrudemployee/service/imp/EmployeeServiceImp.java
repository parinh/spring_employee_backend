package com.example.restcrudemployee.service.imp;


import com.example.restcrudemployee.entity.Employee;
import com.example.restcrudemployee.exception.EmployeeNotFoundException;
import com.example.restcrudemployee.repository.EmployeeRepository;
import com.example.restcrudemployee.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class EmployeeServiceImp implements EmployeeService {
    public EmployeeServiceImp(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    private EmployeeRepository employeeRepository;

    @Override
    public List<Employee> findAll() {
        return employeeRepository.findAll();
    }

    @Override
    public Employee getById(int id) {
        //? WhereIf
        Employee employee = employeeRepository.findById(id).orElse(null);
        if(employee != null){
            return employee;
        }
        else{
            throw new EmployeeNotFoundException("Cant find this Id.");
        }

    }

    @Override
    public Employee save(Employee new_employee) {
        return employeeRepository.save(new_employee);
    }

    @Override
    public void update(Employee req_employee) {
        Optional<Employee> employee = employeeRepository.findById(req_employee.getId());
        if(employee.isPresent()){
            Employee toUpdated = employee.get();
            toUpdated.setFirstName(req_employee.getFirstName());
            toUpdated.setLastName(req_employee.getLastName());
            toUpdated.setNickName(req_employee.getNickName());
            toUpdated.setAddress(req_employee.getAddress());
            employeeRepository.save(toUpdated);
        }
        else{
            throw new EmployeeNotFoundException("Cant find this Id.");
        }

    }

    @Override
    public void delete(int id) {
        Optional<Employee> employee = employeeRepository.findById(id);
        if(employee.isPresent()){
            Employee toUpdated = employee.get();
            toUpdated.setStatus("deleted");
            employeeRepository.save(toUpdated);
        }
        else{
            throw new EmployeeNotFoundException("Cant find this Id.");
        }
    }

    @Override
    public void updateSalaryByPercent(Integer id, Integer percent) {
        Optional<Employee> employee = employeeRepository.findById(id);
        if(employee.isPresent()){
            Employee toUpdated = employee.get();
            int new_salary = toUpdated.getSalary() + (toUpdated.getSalary() * percent)/100;
            toUpdated.setSalary(new_salary);
            employeeRepository.save(toUpdated);
        }
        else{
            throw new EmployeeNotFoundException("Cant find this Id.");
        }
    }

    @Override
    public void updatePosition(Integer id, String old_pos,String new_pos) {
        Optional<Employee> employee = employeeRepository.findById(id);
        if(employee.isPresent()){
           Employee toUpdated = employee.get();
           if(toUpdated.getPosition().equals(old_pos)){
               toUpdated.setPosition(new_pos);
               employeeRepository.save(toUpdated);
           }
           else{
               throw new RuntimeException("Current position is incorrect");
           }
        }
        else{
            throw new EmployeeNotFoundException("Cant find this Id.");
        }
    }

    @Override
    public List<Employee> getLikeInName(String sub_str) {
        return employeeRepository.findByFirstNameLike("%"+ sub_str +"%");
    }

    @Override
    public List<Integer> deleteByIds(List<Integer> ids) {
        List<Integer> notfound_list = new ArrayList<>();
        for (int id: ids) {
            Optional<Employee> employee = employeeRepository.findById(id);
            if(employee.isPresent()){
                Employee toUpdated = employee.get();
                toUpdated.setStatus("deleted");
                employeeRepository.save(toUpdated);
            }
            else{
                notfound_list.add(id);
            }
        }
        return notfound_list;
    }
}
